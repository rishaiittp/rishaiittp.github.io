Secondary Sliding Navigation
=========

A bold, secondary menu that slides over the main navigation.

[Article on CodyHouse](http://codyhouse.co/gem/secondary-sliding-navigation/)

[Demo](http://codyhouse.co/demo/secondary-sliding-navigation/index.html)
 
[Terms](http://codyhouse.co/terms/)
